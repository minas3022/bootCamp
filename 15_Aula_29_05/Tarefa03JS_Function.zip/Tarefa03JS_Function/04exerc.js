function multiplicacao(num1, num2) {
    return num1 * num2;
}

// Exemplo de uso
let resultado = multiplicacao(5, 10);
console.log(resultado); 
