function subtracao(num1, num2) {
    return num2 - num1;
}

// Exemplo de uso
let resultado = subtracao(12, 38);
console.log(resultado); 
