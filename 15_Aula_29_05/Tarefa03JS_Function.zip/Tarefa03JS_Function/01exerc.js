//FUNCAO DE SAUDACAO ... 
function saudacao(nome) {
    console.log("Olá, " + nome + "! Bem-vindo(a)!");
}

// Exemplo de uso
saudacao("Maria");