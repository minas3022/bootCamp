function soma(num1, num2) {
    return num1 + num2;
}

// Exemplo de uso
let resultado = soma(25, 10);
console.log(resultado); // 35