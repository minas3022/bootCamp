//Crie um trecho de código que me diga quanto cobrar para vender um notebook usado: o seu custo foi R$3000, por quanto devo vendê-lo descontando 25%
let custoOriginal=3000;
let desconto=custoOriginal*0.25;
let precoVenda=custoOriginal-desconto;
console.log("O preço de venda é: " + precoVenda);