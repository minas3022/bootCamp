/* Escreva um programa que leia um valor de uma temperatura em CELSIUS e converte para FAHRENHEIT. O cálculo é: CELSIUS * 1,8 + 32. */
let celsius=100;
let fahrenheit=celsius * 1.8 + 32;
console.log(celsius + "°C é igual a " + fahrenheit + "°F");
