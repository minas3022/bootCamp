//Escreva um programa que leia um valor em metros e o exiba no console convertido em milímetros
let metros=3
let milimetros=metros*1000
console.log("3 metros corresponde a : " + milimetros+" milimetros");
