let idade=53;
let anoAtual = new Date().getFullYear(); /* atribui variavel ao ano corrente */
let anoNascimento=anoAtual-idade;
console.log("O ano que você nasceu é: " + anoNascimento);
