// DECLARANDO AS VARIAVEIS DE PESO E ALTURA
let peso = 80; // Peso em kg
let altura = 1.75; // Altura em metros
let calculo=altura^2
// CALCULANDO O IMS
let imc = peso / (calculo);

// EXIBINDO O IMC NO CONSOLE.
console.log("O IMC é: " + imc.toFixed(2)); // .toFixed(2) para exibir o IMC com duas casas decimais
