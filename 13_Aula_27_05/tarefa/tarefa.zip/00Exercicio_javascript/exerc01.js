// DECLARANDO AS VARIAVEIS DE NOTAS 
let nota1 = 5.5;
let nota2 = 7.0;
let nota3 = 6.5;

// FAZENDO OS CALCULOS MEDIA OU SEJA POR 3
let media = (nota1 + nota2 + nota3) / 3;

// RESULTADO FINAL CONFORME CONSOLE
console.log("A média das notas é: " + media.toFixed(2)); // .toFixed(2) para exibir a média com duas casas decimais
